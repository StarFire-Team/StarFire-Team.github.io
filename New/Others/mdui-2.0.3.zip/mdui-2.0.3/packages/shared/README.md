# @mdui/shared

mdui 内部使用的公共代码

## 安装

```bash
npm install @mdui/shared --save
```





