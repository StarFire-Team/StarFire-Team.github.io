export * from './tabs/tab-panel.js';
