export { observeResize } from '@mdui/shared/helpers/observeResize.js';
export type { ObserveResize } from '@mdui/shared/helpers/observeResize.js';
