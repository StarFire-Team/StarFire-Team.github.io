export { breakpoint } from '@mdui/shared/helpers/breakpoint.js';
